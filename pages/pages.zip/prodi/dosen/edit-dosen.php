<div class="row">
<?php
	if (isset($_GET['id_dosen'])) {
		$id_dosen = $_GET['id_dosen'];
	}
	else {
		die ("Error. No Kode Selected! ");	
	}
	include "../../config/koneksi.php";
	$query	= mysqli_query($gathuk, "SELECT * FROM tb_dosen WHERE id_dosen='$id_dosen'");
	$hasil	= mysqli_fetch_array ($query);
		$notno	=$hasil['nidn'];
				
	if ($_POST['edit'] == "edit") {
	$nidn	=$_POST['nidn'];
	$nama	=addslashes($_POST['nama']);
	$bdstudi	=addslashes($_POST['bdstudi']);
	
	$cekno	=mysqli_num_rows (mysqli_query($gathuk, "SELECT nidn FROM tb_dosen WHERE nidn='$_POST[nidn]' AND nidn!='$notno'"));
	
	$cekno1	=mysqli_num_rows (mysqli_query($gathuk, "SELECT npm FROM tb_siswa WHERE npm='$_POST[nidn]'"));
	
		if (empty($_POST['nidn']) || empty($_POST['nama']) || empty($_POST['bdstudi'])) {
			$_SESSION['pesan'] = "Oops! Please fill all column ...";
			header("location:index.php?page=form-view-data-dosen");
		}
		else if($cekno > 0) {
			$_SESSION['pesan'] = "Oops! Duplikat NIDN ...";
			header("location:index.php?page=form-view-data-dosen");
		}
		else if($cekno1 > 0) {
			$_SESSION['pesan'] = "Oops! Duplikat NIDN vs NPM ...";
			header("location:index.php?page=form-view-data-dosen");
		}
		
		else{
		$update= mysqli_query ($gathuk, "UPDATE tb_dosen SET nidn='$nidn',nama='$nama', bdstudi='$bdstudi' WHERE id_dosen='$id_dosen'");
		
		$updateusr= mysqli_query ($gathuk, "UPDATE tb_user SET id_user='$nidn',nama_user='$nama' WHERE id_dosen='$id_dosen'");
		
			if($update){
				$_SESSION['pesan'] = "Good! Edit data dosen success ...";
				header("location:index.php?page=form-view-data-dosen");
			}
			else {
				echo "<div class='register-logo'><b>Oops!</b> 404 Error Server.</div>";
			}
		}
	}
?>
</div>