<?php
ob_start();
session_start();
if(!isset($_SESSION['id_user'])){
    die("<b>Oops!</b> Access Failed.
		<p>Sistem Logout. Anda harus melakukan Login kembali.</p>
		<button type='button' onclick=location.href='../../'>Back</button>");
}
if($_SESSION['hak_akses']!="Prodi"){
    die("<b>Oops!</b> Access Failed.
		<p>Anda Bukan Prodi.</p>
		<button type='button' onclick=location.href='../../'>Back</button>");
}
	include "../../config/koneksi.php";
	$tampilUsr	=mysqli_query($gathuk, "SELECT * FROM tb_user WHERE id_user='$_SESSION[id_user]'");
	$usr		=mysqli_fetch_array($tampilUsr);	
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
<head>
	<meta charset="utf-8" />
	<title>Sistem Informasi Pengajuan Judul Skripsi | AKADEMIK PENUSA</title>
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="keywords" />
	<meta content="Jasa Aplikasi dan Web" name="author" />
	<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon" />	
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
	<link href="../../assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css" rel="stylesheet" />
	<link href="../../assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="../../assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="../../assets/plugins/ionicons/css/ionicons.min.css" rel="stylesheet" />
	<link href="../../assets/css/animate.min.css" rel="stylesheet" />
	<link href="../../assets/css/style.min.css" rel="stylesheet" />
	<link href="../../assets/css/style-responsive.min.css" rel="stylesheet" />
	<link href="../../assets/css/theme/default.css" rel="stylesheet" id="theme" />
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="../../assets/plugins/jquery-jvectormap/jquery-jvectormap.css" rel="stylesheet" />
	<link href="../../assets/plugins/gritter/css/jquery.gritter.css" rel="stylesheet" />
	<link href="../../assets/plugins/DataTables/media/css/dataTables.bootstrap.min.css" rel="stylesheet" />
	<link href="../../assets/plugins/DataTables/media/css/dataTables.bootstrap.min.css" rel="stylesheet" />
	<link href="../../assets/plugins/DataTables/extensions/Responsive/css/responsive.bootstrap.min.css" rel="stylesheet" />
	
	<link href="../../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" />
	<link href="../../assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.css" rel="stylesheet" />
	<link href="../../assets/plugins/ionRangeSlider/css/ion.rangeSlider.css" rel="stylesheet" />
	<link href="../../assets/plugins/ionRangeSlider/css/ion.rangeSlider.skinNice.css" rel="stylesheet" />
	<link href="../../assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet" />
	<link href="../../assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet" />
	<link href="../../assets/plugins/password-indicator/css/password-indicator.css" rel="stylesheet" />
	<link href="../../assets/plugins/bootstrap-combobox/css/bootstrap-combobox.css" rel="stylesheet" />
	<link href="../../assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
	<link href="../../assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet" />
	<link href="../../assets/plugins/jquery-tag-it/css/jquery.tagit.css" rel="stylesheet" />
    <link href="../../assets/plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet" />
    <link href="../../assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" />
    <link href="../../assets/plugins/bootstrap-eonasdan-datetimepicker/build/css/bootstrap-datetimepicker.min.css" rel="stylesheet" />
    <link href="../../assets/plugins/bootstrap-colorpalette/css/bootstrap-colorpalette.css" rel="stylesheet" />
    <link href="../../assets/plugins/jquery-simplecolorpicker/jquery.simplecolorpicker.css" rel="stylesheet" />
    <link href="../../assets/plugins/jquery-simplecolorpicker/jquery.simplecolorpicker-fontawesome.css" rel="stylesheet" />
    <link href="../../assets/plugins/jquery-simplecolorpicker/jquery.simplecolorpicker-glyphicons.css" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="../../assets/plugins/jquery/jquery-2.1.4.min.js"></script>
	<script src="../../assets/plugins/pace/pace.min.js"></script>
	<!-- ================== END BASE JS ================== -->
</head>
<body>
	<!-- begin #page-loader -->
	<div id="page-loader" class="fade in"><span class="spinner"></span></div>
	<!-- end #page-loader -->
	<!-- begin #page-container -->
	<div id="page-container" class="fade page-sidebar-fixed page-header-fixed page-with-light-sidebar">
		<!-- begin #header -->
		<div id="header" class="header navbar navbar-default navbar-fixed-top bg-white">
			<!-- begin container-fluid -->
			<div class="container-fluid">
				<!-- begin mobile sidebar expand / collapse button -->
				<div class="navbar-header" >
					<a href="./" class="navbar-brand"><span class="navbar-logo"><i class="fa fa-dropbox text-danger"></i></span>&nbsp;<b>PENUSA</b> APP</a>
					<button type="button" class="navbar-toggle" data-click="sidebar-toggled">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- end mobile sidebar expand / collapse button -->
				<!-- begin navbar-collapse -->
                <div class="collapse navbar-collapse pull-left" id="top-navbar">
                    <ul class="nav navbar-nav">
						<li><a href="javascript:;" data-click="sidebar-minify"><i class="ion-navicon-round m-r-5 f-s-20 pull-left text-inverse"></i></a></li>
					</ul>
                </div>
				<!-- end navbar-collapse -->	
				<!-- begin header navigation right -->
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown navbar-user">
						<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
							<span class="user-image online"><img src="../../assets/img/no-avatar.jpg" alt="" /></span>
							<span class="hidden-xs"><span class="text-warning">Welcome , </span><?=$usr['nama_user']?></span> <span class="text-warning"><i class="fa fa-caret-down"></i></span>
						</a>
						<ul class="dropdown-menu animated fadeInLeft">
							<li class="arrow"></li>
							<li><a href="index.php?page=form-ganti-password"><i class="ion-ios-locked"></i> &nbsp;Change Password</a></li>
							<li class="divider"></li>
							<li><a href="../../restric/logout.php"><i class="ion-power"></i> &nbsp;Log Out</a></li>
						</ul>
					</li>
				</ul>
				<!-- end header navigation right -->
			</div>
			<!-- end container-fluid -->
		</div>
		<!-- end #header -->
		<!-- begin #sidebar -->
		<div id="sidebar" class="sidebar">
			<!-- begin sidebar scrollbar -->
			<div data-scrollbar="true" data-height="100%">
				<!-- begin sidebar user -->
				<ul class="nav">
					<li class="nav-profile">
						<div class="image">
							<a href="javascript:;"><img src="../../assets/img/no-avatar.jpg" alt="" /></a>
						</div>
						<div class="info">
							<?=$usr['nama_user']?>
							<small><?=$usr['hak_akses']?></small>
						</div>
					</li>
				</ul>
				<!-- end sidebar user -->
				<!-- begin sidebar nav -->
				<ul class="nav">
					<li class="nav-header">Navigation <i class="fa fa-paper-plane m-l-5"></i></li>
					<li><a href="./"><i class="ion-ios-pulse bg-blue"></i><span>Dashboard</span> <span class="badge bg-danger pull-right">HOME</span></a></li>
					<li class="has-sub">
						<a href="javascript:;"><b class="caret pull-right"></b><i class="ion-ios-gear-outline bg-blue"></i><span>Management Setup</span></a>
						<ul class="sub-menu">
							<li><a href="index.php?page=form-view-setup-universitas"><i class="menu-icon fa fa-caret-right"></i> &nbsp;Universitas</a></li>
							<li><a href="index.php?page=form-view-data-user"><i class="menu-icon fa fa-caret-right"></i> &nbsp;User</a></li>
						</ul>
					</li>
					<li class="has-sub">
						<a href="javascript:;"><b class="caret pull-right"></b><i class="ion-ios-color-filter-outline bg-purple"></i><span>Master Data</span></a>
						<ul class="sub-menu">
							<li><a href="index.php?page=form-view-data-bdstudi"><i class="menu-icon fa fa-caret-right"></i> &nbsp;Bidang Studi</a></li>
							<li><a href="index.php?page=form-view-data-jurusan"><i class="menu-icon fa fa-caret-right"></i> &nbsp;Jurusan</a></li>
							<li><a href="index.php?page=form-view-data-kategori"><i class="menu-icon fa fa-caret-right"></i> &nbsp;Kategori</a></li>
						</ul>
					</li>
					<li><a href="index.php?page=form-view-data-dosen"><i class="ion-ios-personadd-outline bg-danger"></i><span>Dosen</span></a></li>
					<li><a href="index.php?page=form-view-data-siswa"><i class="ion-ios-personadd-outline bg-warning"></i><span>Siswa</span></a></li>
					<li><a href="index.php?page=form-view-data-berkas"><i class="ion-ios-paper-outline bg-gradient-blue"></i><span>Berkas&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="label label-warning m-l-4">APPROVAL</span></span></a></li>
					<li><a href="index.php?page=form-view-data-skripsi"><i class="ion-university bg-danger"></i><span>Pengajuan Judul Skripsi</span></a></li>
					<li class="has-sub">
						<a href="javascript:;"><b class="caret pull-right"></b><i class="ion-ios-browsers-outline bg-purple"></i><span>View Data</span></a>
						<ul class="sub-menu">
							<li><a href="index.php?page=form-view-judul"><i class="menu-icon fa fa-caret-right"></i> &nbsp;Kategori Skripsi</a></li>
							<li><a href="index.php?page=form-view-angkatan"><i class="menu-icon fa fa-caret-right"></i> &nbsp;Angkatan</a></li>
							<li><a href="index.php?page=form-view-tahun"><i class="menu-icon fa fa-caret-right"></i> &nbsp;Tahun Pengajuan</a></li>
						</ul>
					</li>
					<li class="has-sub">
						<a href="javascript:;"><b class="caret pull-right"></b><i class="ion-printer bg-info"></i><span>Report</span></a>
						<ul class="sub-menu">
							<li><a href="index.php?page=report-skripsi-siswa"><i class="menu-icon fa fa-caret-right"></i> &nbsp;Pengajuan Skripsi</a></li>
							<li><a href="index.php?page=report-judul-skripsi"><i class="menu-icon fa fa-caret-right"></i> &nbsp;Daftar Judul Skripsi</a></li>
						</ul>
					</li>
					<li><a href="index.php?page=backup-data"><i class="ion-ios-cloud-download-outline bg-success"></i><span>Backup DB</span></a></li>
					<!-- begin sidebar minify button -->
					<li><a href="javascript:;" class="sidebar-minify-btn grey" data-click="sidebar-minify"><i class="ion-ios-arrow-left"></i> <span>Collapse</span></a></li>
			        <!-- end sidebar minify button -->
				</ul>
				<!-- end sidebar nav -->
			</div>
			<!-- end sidebar scrollbar -->
		</div>
		<div class="sidebar-bg"></div>
		<!-- end #sidebar -->
		<!-- begin #content -->
		<div id="content" class="content">
			<?php
				$page = (isset($_GET['page']))? $_GET['page'] : "main";
				switch ($page) {
					case 'form-view-setup-universitas': include "../../pages/prodi/setup/universitas/form-view-setup-universitas.php"; break;
					case 'form-setup-universitas': include "../../pages/prodi/setup/universitas/form-setup-universitas.php"; break;
					case 'setup-universitas': include "../../pages/prodi/setup/universitas/setup-universitas.php"; break;
					
					case 'form-view-data-user': include "../../pages/prodi/user/form-view-data-user.php"; break;
					case 'reset-password': include "../../pages/prodi/user/reset-password.php"; break;
					//
					case 'form-view-data-bdstudi': include "../../pages/prodi/master/bdstudi/form-view-data-bdstudi.php"; break;
					case 'master-bdstudi': include "../../pages/prodi/master/bdstudi/master-bdstudi.php"; break;
					case 'edit-bdstudi': include "../../pages/prodi/master/bdstudi/edit-bdstudi.php"; break;
					case 'delete-bdstudi': include "../../pages/prodi/master/bdstudi/delete-bdstudi.php"; break;
					
					case 'form-view-data-jurusan': include "../../pages/prodi/master/jurusan/form-view-data-jurusan.php"; break;
					case 'master-jurusan': include "../../pages/prodi/master/jurusan/master-jurusan.php"; break;
					case 'edit-jurusan': include "../../pages/prodi/master/jurusan/edit-jurusan.php"; break;
					case 'delete-jurusan': include "../../pages/prodi/master/jurusan/delete-jurusan.php"; break;
					
					case 'form-view-data-kategori': include "../../pages/prodi/master/kategori/form-view-data-kategori.php"; break;
					case 'master-kategori': include "../../pages/prodi/master/kategori/master-kategori.php"; break;
					case 'edit-kategori': include "../../pages/prodi/master/kategori/edit-kategori.php"; break;
					case 'delete-kategori': include "../../pages/prodi/master/kategori/delete-kategori.php"; break;
					//
					case 'form-view-data-dosen': include "../../pages/prodi/dosen/form-view-data-dosen.php"; break;
					case 'master-dosen': include "../../pages/prodi/dosen/master-dosen.php"; break;
					case 'edit-dosen': include "../../pages/prodi/dosen/edit-dosen.php"; break;
					case 'aktivasi-dosen': include "../../pages/prodi/dosen/aktivasi-dosen.php"; break;
					case 'delete-dosen': include "../../pages/prodi/dosen/delete-dosen.php"; break;
					
					case 'form-view-data-siswa': include "../../pages/prodi/siswa/form-view-data-siswa.php"; break;
					case 'master-siswa': include "../../pages/prodi/siswa/master-siswa.php"; break;
					case 'edit-siswa': include "../../pages/prodi/siswa/edit-siswa.php"; break;
					case 'aktivasi-siswa': include "../../pages/prodi/siswa/aktivasi-siswa.php"; break;
					case 'delete-siswa': include "../../pages/prodi/siswa/delete-siswa.php"; break;
					//
					case 'form-view-data-berkas': include "../../pages/prodi/berkas/form-view-data-berkas.php"; break;
					case 'approval-berkas': include "../../pages/prodi/berkas/approval-berkas.php"; break;
					
					case 'form-view-data-skripsi': include "../../pages/prodi/skripsi/form-view-data-skripsi.php"; break;
					case 'approval-skripsi': include "../../pages/prodi/skripsi/approval-skripsi.php"; break;
					case 'send-to-dosen': include "../../pages/prodi/skripsi/send-to-dosen.php"; break;
					//
					case 'form-view-judul': include "../../pages/prodi/view/form-view-judul.php"; break;
					case 'form-view-angkatan': include "../../pages/prodi/view/form-view-angkatan.php"; break;
					case 'form-view-tahun': include "../../pages/prodi/view/form-view-tahun.php"; break;
					
					case 'report-skripsi-siswa': include "../../pages/prodi/report/report-skripsi-siswa.php"; break;
					case 'report-judul-skripsi': include "../../pages/prodi/report/report-judul-skripsi.php"; break;
					
					case 'form-ganti-password': include "../../pages/prodi/form-ganti-password.php"; break;
					case 'ganti-password': include "../../pages/prodi/ganti-password.php"; break;
					
					case 'backup-data': include "../../pages/prodi/backup/backup-data.php"; break;
					
					default : include '../../pages/prodi/dashboard.php';	
				}
			?>
		</div>
		<!-- end #content -->
		<!-- begin #footer -->
		<div id="footer" class="footer">
		    &copy; 2020. <a href="./">AKADEMIK</a> Version 1.0 - All Rights Reserved
		</div>
		<!-- end #footer -->
        <!-- begin theme-panel -->
        
        <!-- end theme-panel -->
		<!-- begin scroll to top btn -->
		<a href="javascript:;" class="btn btn-icon btn-circle btn-primary btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
		<!-- end scroll to top btn -->
	</div>
	<!-- end page container -->
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="../../assets/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="../../assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="../../assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="../../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<!--[if lt IE 9]>
		<script src="assets/crossbrowserjs/html5shiv.js"></script>
		<script src="assets/crossbrowserjs/respond.min.js"></script>
		<script src="assets/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	<script src="../../assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="../../assets/plugins/jquery-cookie/jquery.cookie.js"></script>
	<!-- ================== END BASE JS ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="../../assets/plugins/gritter/js/jquery.gritter.js"></script>
	<script src="../../assets/plugins/flot/jquery.flot.min.js"></script>
	<script src="../../assets/plugins/flot/jquery.flot.time.min.js"></script>
	<script src="../../assets/plugins/flot/jquery.flot.resize.min.js"></script>
	<script src="../../assets/plugins/flot/jquery.flot.pie.min.js"></script>
	<script src="../../assets/plugins/sparkline/jquery.sparkline.js"></script>
	<script src="../../assets/plugins/jquery-jvectormap/jquery-jvectormap.min.js"></script>
	<script src="../../assets/plugins/jquery-jvectormap/jquery-jvectormap-world-mill-en.js"></script>
	<script src="../../assets/plugins/DataTables/media/js/jquery.dataTables.js"></script>
	<script src="../../assets/plugins/DataTables/media/js/dataTables.bootstrap.min.js"></script>
	<script src="../../assets/plugins/DataTables/extensions/Responsive/js/dataTables.responsive.min.js"></script>
	<script src="../../assets/js/table-manage-responsive.demo.min.js"></script>
	
	<script src="../../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
	<script src="../../assets/plugins/ionRangeSlider/js/ion-rangeSlider/ion.rangeSlider.min.js"></script>
	<script src="../../assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
	<script src="../../assets/plugins/masked-input/masked-input.min.js"></script>
	<script src="../../assets/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
	<script src="../../assets/plugins/password-indicator/js/password-indicator.js"></script>
	<script src="../../assets/plugins/bootstrap-combobox/js/bootstrap-combobox.js"></script>
	<script src="../../assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>
	<script src="../../assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
	<script src="../../assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput-typeahead.js"></script>
	<script src="../../assets/plugins/jquery-tag-it/js/tag-it.min.js"></script>
    <script src="../../assets/plugins/bootstrap-daterangepicker/moment.js"></script>
    <script src="../../assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
    <script src="../../assets/plugins/select2/dist/js/select2.min.js"></script>
    <script src="../../assets/plugins/bootstrap-eonasdan-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
    <script src="../../assets/plugins/bootstrap-show-password/bootstrap-show-password.js"></script>
    <script src="../../assets/plugins/bootstrap-colorpalette/js/bootstrap-colorpalette.js"></script>
    <script src="../../assets/plugins/jquery-simplecolorpicker/jquery.simplecolorpicker.js"></script>
    <script src="../../assets/plugins/clipboard/clipboard.min.js"></script>
	<script src="../../assets/js/form-plugins.demo.min.js"></script>
	<script src="../../assets/js/dashboard.min.js"></script>
	<script src="../../assets/js/apps.min.js"></script>
	<!-- ================== END PAGE LEVEL JS ================== -->
	
	<script>
		$(document).ready(function() {
			App.init();
			TableManageResponsive.init();
			FormPlugins.init();
		});
	</script>
</body>
</html>